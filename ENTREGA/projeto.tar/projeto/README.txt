Nomes: Gustavo Henrique Faustino Silva                      Números USP: 9298260
       Isabela Blücher                                                   9298170
       Luís Felipe de Melo Costa Silva                                   9297961

ARQUIVO README

Compilação: Basta usar o arquivo Makefile anexado, da seguinte forma:
        $ make

Execução: Para executar, rode o seguinte comando:
        $ ./projeto <ARQUIVO> <SAIDA> <MAX_ITER> <N_PROCS>

        Onde ARQUIVO é uma imagem de entrada com formato PPM, SAIDA é o nome do 
        arquivo .ppm de saída, MAX_ITER é o número de iterações que o sistema 
        vai rodar e N_PROCS o número de threads.